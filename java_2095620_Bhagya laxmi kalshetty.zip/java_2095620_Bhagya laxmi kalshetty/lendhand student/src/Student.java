
public class Student {
	int registrationid;
	public void displayRegistrationId(){
		System.out.println("The student registration id is:"+registrationid);
	}

}
