
public class StudentMain {

	public static void main(String[] args) {
		Student stud=new Student();
		stud.registrationid=1290;
		stud.displayRegistrationId();

	}

}
