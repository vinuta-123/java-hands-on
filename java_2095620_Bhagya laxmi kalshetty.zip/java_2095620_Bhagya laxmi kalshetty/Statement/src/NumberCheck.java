
public class NumberCheck {
	int num1;
	int num2;
	int num3;
	public void displayBigNumber(){
		
		if(num1>num2&&num1>num3){
			System.out.println(num1+":The biggest number");
		}
		else if(num2>num3){
			System.out.println(num2+"The biggest number");
		}
		else{
			System.out.println(num3+":The biggest number");
		}
	}

}
