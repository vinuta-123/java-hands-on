
public class MainProgram {

	public static void main(String[] args) {
		NumberCheck nc=new NumberCheck();
		nc.num1=11;
		nc.num2=18;
		nc.num3=17;
		nc.displayBigNumber();
	}

}
