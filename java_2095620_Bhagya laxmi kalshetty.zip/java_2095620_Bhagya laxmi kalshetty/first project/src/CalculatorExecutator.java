
public class CalculatorExecutator {

	public static void main(String[] args) {
		Calculator cal=new Calculator();
		cal.operand1=89;
		cal.operand2=32;
		cal.displayOperand();
		
	}

}
