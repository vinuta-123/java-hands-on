
public class Employee {
long empid=345;
double empTax=9.5;
double empsalary=10000;
int empDaysOfWork=24;
public Object displayEmplyoee;
void calculatePf(){
	double PfRate=10.5;
	System.out.println("The pf rate of emplyoee is:"+PfRate);
	
}
}
