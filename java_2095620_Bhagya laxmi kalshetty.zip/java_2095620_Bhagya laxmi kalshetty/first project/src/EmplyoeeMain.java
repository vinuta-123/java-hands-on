
public class EmplyoeeMain {

	public static void main(String[] args) {
		Employee em=new Employee();
		System.out.println("The id of emplyoee is:"+em.empid);
		System.out.println("The salary of emplyoee is:"+em.empsalary);
		System.out.println("The percentage of tax emplyoee to be paid is:"+em.empTax);
		System.out.println("The total no of working days is:"+em.empDaysOfWork);
		em.calculatePf();
	}

}
