
public class Calculator {
	int operand1;
	int operand2;
	public void displayOperand(){
		System.out.println("The value of operand 1 is:"+operand1);
		System.out.println("The value of operand 2 is:"+operand2);
	}

}
