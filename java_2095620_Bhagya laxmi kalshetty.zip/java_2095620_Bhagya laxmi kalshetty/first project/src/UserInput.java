import java.util.Scanner;

public class UserInput {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your reg num:");
		int RegNum=Integer.parseInt(scanner.next());
		System.out.println("no:"+RegNum);
	}

}
