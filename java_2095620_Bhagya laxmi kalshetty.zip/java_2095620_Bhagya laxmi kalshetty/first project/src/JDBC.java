import java.sql.*;
public class JDBC {

	private static final String Create = null;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Akshata","root","2323");
		System.out.println("connected...");
		
		
		
		

	}

}
