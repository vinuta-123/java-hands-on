
public class MainProgram {

	public static void main(String[] args) {
		Calculator calc=new Calculator();
		calc.num1=15;
		calc.num2=5;
		calc. BitwiseAnd();
		calc. BitwiseOr();
		calc. BitwiseXor();
		calc. BitwiseNot();

	}
	

}
