
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
public class OnceAgain {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Driver driver=new com.mysql.cj.jdbc.Driver();
		DriverManager.registerDriver(driver);
		DriverManager.getConnection("jdbc:mysql://local host:3306/akshata","root", "2323");
		System.out.println("connected..");
			}

	}


