
public class Calculator {
int num1;
int num2;
int result;
public void BitwiseAnd(){
	result=num1&num2;
	System.out.println("the bitwise and:"+result);
}
public void BitwiseOr(){
	result=num1|num2;
	System.out.println("the bitwise or:"+result);
}
public void BitwiseXor(){
	result=num1^num2;
	System.out.println("the bitwise xor:"+result);
}
public void BitwiseNot(){
	result=~num1;
	System.out.println("the bitwise xor:"+result);
}
}
