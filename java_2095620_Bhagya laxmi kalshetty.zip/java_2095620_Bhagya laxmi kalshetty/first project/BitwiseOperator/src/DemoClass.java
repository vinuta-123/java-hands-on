import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Result;
import com.mysql.cj.xdevapi.Statement;

public class DemoClass {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String query="select"
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Akshata","root","2323");
		java.sql.Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(query)
		
		

	}

}
