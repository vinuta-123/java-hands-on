package com.cognizant;

import java.util.Scanner;

public class AreaCalculator {

	public static void main(String[] args) {
		
	}

}
