
public class Main {

public static void main(String[] args){
		// TODO Auto-generated method stub
		public Result Main(Student student){
			int total=student.mark1+student.mark2;
			Result result =new Result();
			result.StudentId=student.StudentId;
			if(total/2<60){
				result.grade="Fail";
			}
			else{
				result.grade="pass";
			}
			
		}
	}
}



