
public class Result {
	String StudentId;
	String grade;

}
