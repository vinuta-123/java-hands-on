
public class Student {
	String StudentId;
	int mark1;
	int mark2;

}