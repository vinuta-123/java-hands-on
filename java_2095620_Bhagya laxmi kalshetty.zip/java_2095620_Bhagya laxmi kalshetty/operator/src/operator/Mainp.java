package operator;
public class Mainp {

	public static void main(String[] args) {
		Calcu ca=new Calcu();
		ca.num1=12;

		ca.num2=8;
		ca.addition();
		ca.substraction();
		ca.printSmaller();
		
	}

}
