package operator;
public class Calcu {
	int num1;
	int num2;
	int result;
	public void addition(){
	 result=num1+num2;
	 System.out.println("The addition of 2 variable is:"+result);
	}
	public void substraction(){
		result=num1-num2;
		System.out.println("The substraction of 2 variable is:"+result);
	}
	public void printSmaller(){
		if(num1>num2){
			System.out.println("num1 is bigger:"+num1);
		}
		else{
			System.out.println("num2 is bigger:"+num2);
		}
	}

}
