
public class Daughter extends Parent {
public void star(){
	System.out.println("I am");
}
}
