
public class Parent {
	int reg;
	public void display(){
		System.out.println("Hello");
	}
	

}

