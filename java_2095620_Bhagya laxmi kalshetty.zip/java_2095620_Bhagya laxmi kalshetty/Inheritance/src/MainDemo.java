
public class MainDemo {

	private static String reg;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Daughter den=new Daughter();
   den.reg=1;
   System.out.println("the entered reg no is:"+den.reg);
   son sun=new son();
   den.display();
   den.star();
   sun.gun();
   sun.display();
  
   
	}

}
