
public class son extends Parent {
	public void gun(){
		System.out.println("there");
	}

}
