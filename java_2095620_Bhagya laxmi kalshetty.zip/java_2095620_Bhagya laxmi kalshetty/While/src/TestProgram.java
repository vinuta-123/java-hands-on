
public class TestProgram {

	public static void main(String[] args) {
		WelcomeMessage wm=new WelcomeMessage();
		int i=1;
		while(i<=5)
		{
			wm.printMessage();
			i++;
		}

	}

}
