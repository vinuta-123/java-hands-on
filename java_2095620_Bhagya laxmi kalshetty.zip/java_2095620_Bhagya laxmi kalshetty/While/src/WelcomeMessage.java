
public class WelcomeMessage {
	public void printMessage(){
		System.out.println("Welcome All");
	}

}
