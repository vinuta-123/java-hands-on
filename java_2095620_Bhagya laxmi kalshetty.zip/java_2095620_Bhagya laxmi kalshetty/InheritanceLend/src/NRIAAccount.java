
public class NRIAAccount extends BankAccount {
	public void applyFixedDeposit(){
		intrestRate=6.5;
		System.out.println("The intrest rate is:"+intrestRate);
	}

}
