
public class SeniorCitizen extends BankAccount {
	public void applyFixedDeposit(){
		intrestRate=10.5;
		System.out.println("The intrestrate is:"+intrestRate);
		
	}

}
