
public class InheritanceDemo {

	public static void main(String[] args) {
		NRIAAccount nri=new NRIAAccount();
		SeniorCitizen sc=new SeniorCitizen();


	    nri.depositAmount();
		nri.WithdrawMoney();
		nri.applyFixedDeposit();
		sc.depositAmount();
		sc.WithdrawMoney();
		sc.applyFixedDeposit();

	}

}
