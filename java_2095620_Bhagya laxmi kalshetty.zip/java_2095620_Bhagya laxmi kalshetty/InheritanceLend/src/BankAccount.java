
public class BankAccount {
	int WithDrawAmount;
	int depositAmount;
	double intrestRate;
	double balance;
	public void depositAmount(){
		System.out.println("The deposit:"+depositAmount);
	}
	public void WithdrawMoney(){
		System.out.println("The withdraw:"+WithDrawAmount);
		balance=depositAmount-WithDrawAmount;
	}
	

}
