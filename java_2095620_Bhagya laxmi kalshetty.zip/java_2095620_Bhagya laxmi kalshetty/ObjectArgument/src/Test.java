
public class Test {
	int a,b;
	Test(int x,int y){
		a=x;
		b=y;
	}
	void alterPrimitive(int i,int j){
		a=60;
		b=30;
	}
	void alterObject(Test o){
		o.a=25;
		o.b=62;
	}

}

