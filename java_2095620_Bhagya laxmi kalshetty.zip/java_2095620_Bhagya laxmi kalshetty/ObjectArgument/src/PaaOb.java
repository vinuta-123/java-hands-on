
public class PaaOb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test te=new Test(10,20);
		System.out.println("the :"+te.a);
		System.out.println("the :"+te.b);
		te.alterPrimitive(te.a, te.b);
		System.out.println("the :"+te.a);
		System.out.println("the :"+te.b);
		te.alterObject(te);
		System.out.println("the :"+te.a);
		System.out.println("the :"+te.b);
			
		

	}

}
