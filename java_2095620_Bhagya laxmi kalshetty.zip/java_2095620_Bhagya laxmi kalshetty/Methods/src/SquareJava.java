
public class SquareJava {
	int area;
	public int Sum(int length){
		area=length*length;
		return area;
		
	}

}
