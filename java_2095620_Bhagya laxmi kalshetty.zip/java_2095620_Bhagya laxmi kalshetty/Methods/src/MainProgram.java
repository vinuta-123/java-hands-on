
public class MainProgram {

	public static void main(String[] args) {
	  int area=(20);
	  System.out.println("area of square:"+area);

	}

	
}
