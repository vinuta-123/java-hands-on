
public class Dog extends Animal {
	public void WhoIam(){
		System.out.println("I am Dog");
	}

}
