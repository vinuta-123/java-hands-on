
public class RunTimePolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog dog=new Dog();
		Cow cow=new Cow();
		Snake snake=new Snake();
        
		dog.WhoIam();
		cow.WhoIam();
		snake.WhoIam();
		
		

	}

}
