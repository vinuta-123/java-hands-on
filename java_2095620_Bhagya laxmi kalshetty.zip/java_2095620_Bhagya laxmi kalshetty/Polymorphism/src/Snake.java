
public class Snake extends Animal  {
	public void WhoIam(){
		System.out.println("I am snake");
	}

}
