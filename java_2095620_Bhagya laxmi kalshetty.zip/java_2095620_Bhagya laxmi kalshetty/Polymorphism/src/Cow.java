
public class Cow extends Animal {
	public void WhoIam(){
		System.out.println("I am cow");
	}

}
