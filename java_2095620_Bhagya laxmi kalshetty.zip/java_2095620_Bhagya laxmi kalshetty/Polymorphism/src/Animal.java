
public class Animal {
	public void WhoIam(){
		System.out.println("I am animal");
	}

}
