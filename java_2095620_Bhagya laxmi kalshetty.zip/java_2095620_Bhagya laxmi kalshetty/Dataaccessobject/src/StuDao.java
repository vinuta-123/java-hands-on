import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StuDao {
	public void addStudent(student s2) throws Exception{
		String query="insert into student values(?,?)";
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost/Akshata","root","2323");
		PreparedStatement pst=con.prepareStatement(query);
		pst.setInt(1, s2.roll_no);
		pst.setString(2, s2.sname);
		pst.executeUpdate();
	}

}
