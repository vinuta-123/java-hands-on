import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.cj.xdevapi.Statement;
import com.sun.corba.se.pept.transport.Connection;

public class studentDAo {
public student getstudent(int roll_no){
	try{
		String query="Select sname from student where roll_no="+roll_no;
	student s=new student();
	s.roll_no=roll_no;
	Class.forName("com.mysql.jdbc.Driver");
	java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost/Akshata","root","2323");
	java.sql.Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(query);
	rs.next();
	String name=rs.getString(1);
	s.sname=name;
	return s;
	}catch(Exception e){
		System.out.println(e);
	}
	return null;
	
}
}
