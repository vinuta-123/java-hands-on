
public class student {
	int roll_no;
	String sname;

}
