
public class Add {

	public static void main(String[] args) throws Exception {
		
		StuDao dao=new StuDao();
		student s2=new student();
		s2.roll_no=5;
		s2.sname="Archana";
		dao.addStudent(s2);

	}

}

