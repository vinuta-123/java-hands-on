
public class JdbcDemo {
public static void main(String[] args){
	studentDAo dao=new studentDAo();
	student s1=dao.getstudent(4);
	
	System.out.println(s1.sname);
}
}
