import java.text.SimpleDateFormat;
import java.time.Period;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;

public class CustomerDetails{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);	
		
		ArrayList list=new ArrayList();
		System.out.println("enter name");
	String j=sc.next();
	list.add(j);
	System.out.println("enter mobile no");
	long mobile=sc.nextLong();
	list.add(mobile);
	System.out.println("enter checkin date");
	String checkin=sc.next();
	list.add(checkin);
	System.out.println("enter checkout date");
	String checkout=sc.next();
	list.add(checkout);
	for(int i=0;i<1;i++){
		System.out.println("The records are:"+list);
	}
	
		

}
}

