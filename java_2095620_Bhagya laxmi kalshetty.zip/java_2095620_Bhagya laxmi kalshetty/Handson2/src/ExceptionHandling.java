import java.util.Scanner;

public class ExceptionHandling {
	public void HandlingException(){
	Scanner sc=new Scanner(System.in);
	System.out.println("enter room no u want to book");
	int roooms=sc.nextInt();
    try{
    	if(roooms>0)
    		System.out.println("thanks for using this rooms");
    	throw new invalidinputException();
    }
    	catch(Exception e){
    		System.out.println("the exception is:"+e);
    	}
		
		
	
	
	}
}
	



