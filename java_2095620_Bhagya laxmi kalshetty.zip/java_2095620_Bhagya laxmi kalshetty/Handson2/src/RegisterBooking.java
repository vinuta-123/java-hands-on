import java.util.Scanner;
public class RegisterBooking{
	Scanner sc=new Scanner(System.in);
	int reg=sc.nextInt();
	if(reg==1){
		System.out.println("enter your name");
		String name=sc.nextLine();
		
	}
}
	
	
	
	

	
	
	
	
   
	
}
	
	


