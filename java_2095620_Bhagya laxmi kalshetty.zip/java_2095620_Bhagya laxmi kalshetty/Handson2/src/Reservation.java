import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;

public class Reservation {
	
	public void reservationDisplay() throws ParseException{
		Scanner sc=new Scanner(System.in);
		//System.out.println("enter checkin date");
		//String checkin=sc.next();
		//SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	    //System.out.println(checkin);
		LocalDate checkin =LocalDate.of(2019, 02,2);
		
		LocalDate checkout =LocalDate.of(2019, 02,5);
		System.out.println(Period.between( checkin,checkout).getDays());
		//System.out.println("enter checkout date");
		//String checkout=sc.next();
		//System.out.println(checkout);
		System.out.println("enter no of rooms");
		int rooms=sc.nextInt();
		int for_1_day=500;
	    switch(rooms){
	    case 1:
	    	
	    	System.out.println("cost:"+for_1_day*Period.between( checkin,checkout).getDays()*rooms);
	    	break;
	    case 2:
	    	System.out.println("cost:"+for_1_day*Period.between( checkin,checkout).getDays()*rooms);
	    	break;
        case 3:
	    	
	    	System.out.println("cost:"+for_1_day*Period.between( checkin,checkout).getDays()*rooms);
	    	break;
	    	
			
			
		}
		
		
		
	}

	

}
