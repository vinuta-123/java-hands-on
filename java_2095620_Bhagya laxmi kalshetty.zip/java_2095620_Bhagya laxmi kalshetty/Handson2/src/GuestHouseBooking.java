import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class GuestHouseBooking extends Booking {
	
	public void checkin() throws Exception{
		Scanner sc=new Scanner(System.in);
		
	    System.out.println("enter Checkin date(dd/MM/yyyy)");
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		String Checkin=sc.next();
		Date joinDate=sdf.parse(Checkin);
	}
	public void checkout() throws Exception {
		Scanner sc=new Scanner(System.in);
		 System.out.println("enter Checkout date(dd/MM/yyyy)");
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			String Checkout=sc.next();
			Date joinDate=sdf.parse(Checkout);
	}

}
