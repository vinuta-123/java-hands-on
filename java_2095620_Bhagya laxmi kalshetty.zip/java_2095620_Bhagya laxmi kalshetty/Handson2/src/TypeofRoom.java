import java.util.Scanner;

public class TypeofRoom extends GuestHouseBooking {
	public void type(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the type of room u want 1.AC 2.N/AC 3.Function hall");
		int option=sc.nextInt();
		if(option==1){
			System.out.println("The cost is 100 rs more");
		}
		else if(option==2){
			System.out.println("The cost is as per above calculation");
		}
		else if(option==3){
			System.out.println("The cost of function hall is more per day");
		}
		else{
			System.out.println("no option is selected default it take as non Ac room");
		}
		
	}

}
