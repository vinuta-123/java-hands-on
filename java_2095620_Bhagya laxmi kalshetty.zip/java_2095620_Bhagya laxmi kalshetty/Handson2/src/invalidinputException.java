
public class invalidinputException extends Exception {

}
