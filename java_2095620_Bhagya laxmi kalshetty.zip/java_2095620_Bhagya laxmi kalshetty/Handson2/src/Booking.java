import java.util.*;
import java.text.*;

public class Booking {
	public void RoomBooking() throws Exception{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 1 if you want to book 2 if not");
		int reg=sc.nextInt();
		if(reg==1){
			System.out.println("enter name");
			String name=sc.next();
			System.out.println("enter mobile");
			long mobile=sc.nextLong();
			System.out.println("enter email id");
			String emailid=sc.next();
			System.out.println("how many rooms");
			int room=sc.nextInt();
			System.out.println("AC/NAC");
			String type=sc.next();
			System.out.println("enter checkin date");
			String checkin=sc.next();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		    System.out.println(checkin);
			System.out.println("searching");
			System.out.println("enter checkout date");
			String checkout=sc.next();
			System.out.println(checkout);
			int  Availiability[]=new int[5];
			int i;
				for(i=0;i<5;i++){
			System.out.println("enter");
			Availiability[i]=sc.nextInt();
				
		    if(Availiability[i]==0)
			{
			System.out.println("Avaliable");
			}
				}
			
			
			
			
		}
	}

}
