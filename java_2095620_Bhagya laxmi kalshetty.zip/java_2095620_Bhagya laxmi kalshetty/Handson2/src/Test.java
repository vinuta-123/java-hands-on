import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ds=new Scanner(System.in);
		Date thisdate=new Date();
		LocalDate d=LocalDate.of(2021,Month.APRIL,8);
		System.out.println(d);
	    SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		System.out.println(sdf.format(thisdate));

	}

}
