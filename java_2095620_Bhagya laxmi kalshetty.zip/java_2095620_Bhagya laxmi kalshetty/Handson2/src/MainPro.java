import java.util.*;
import java.text.*;
public class MainPro {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//Booking rb=new Booking();
		
		//rb.RoomBooking();
		//Reservation rr=new Reservation();
		//rr.reservationDisplay();
		///GuestHouseBooking ghb=new  GuestHouseBooking();
		//ghb. checkin();
		// ghb.checkout();
		//ghb.RoomBooking();
		//TypeofRoom tp=new TypeofRoom();
		//tp.type();
		ExceptionHandling eh=new ExceptionHandling();
		eh.HandlingException();

	}

}
